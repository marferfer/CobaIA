var juego;
var juego2;
var jugPersonajes;

var juegoPruebas;

var nivelCreadoPrev;

var pad1;
var pad2;
var pad3;
var indicator;

var indicadorJ1;

var cursores;
var escaleras;
var puntajeTexto;

var manos;
var lista_manos = [];

var posimas;
var lista_posimas = [];

var puas;
var lista_puas = [];

var vidas;
var lista_vidas = [];

var rocas;
var lista_rocas = [];


var tecla_laser;

var ctrlW;
var ctrlA;
var ctrlS;
var ctrlD;
var ctrlR;
var ctrlT;
var ctrlU;
var ctrlY;
var lasers;

var mensajes;
var lista_mensajes = [];

var salto = 'salto';
var risa = 'risa';
var posion = 'posion';
var disparo = 'disparo';
var pierde_vida = 'pierde_vida';
var muerte_malo = 'muerte_malo';
var dolor = 'dolor';
var paso = 'paso';
var perder = 'perder';
var maldad = 'maldad';
var maldad_2 = 'maldad_2';
var maldad_3 = 'maldad_3';
var maldad_4 = 'maldad_4';
//var fondo = 'fondo';